﻿CREATE TABLE [dbo].[DriveDB] (
    [DId]            INT             IDENTITY (1, 1) NOT NULL,
    [Gmail_From]     NVARCHAR (100)  NOT NULL,
    [FileName]       VARCHAR (MAX)   NULL,
    [FileData]       VARBINARY (MAX) NULL,
    [Date_of_adding] DATETIME        NULL,
    PRIMARY KEY CLUSTERED ([DId] ASC),
    FOREIGN KEY ([Gmail_From]) REFERENCES [dbo].[LoginDB] ([Gmail_From])
);

CREATE TABLE [dbo].[EmailDB] (
    [Send_Id]     INT            IDENTITY (1, 1) NOT NULL,
    [Gmail_From]  NVARCHAR (100) NOT NULL,
    [Gmail_To]    NVARCHAR (MAX) NULL,
    [Subject]     NVARCHAR (MAX) NULL,
    [Description] NVARCHAR (MAX) NULL,
    [Create_Date] DATETIME       NULL,
    PRIMARY KEY CLUSTERED ([Send_Id] ASC),
    FOREIGN KEY ([Gmail_From]) REFERENCES [dbo].[LoginDB] ([Gmail_From])
);

CREATE TABLE [dbo].[FileAttachment] (
    [Id]         INT             IDENTITY (1, 1) NOT NULL,
    [FileName]   VARCHAR (MAX)   NULL,
    [FileData]   VARBINARY (MAX) NULL,
    [Gmail_From] NVARCHAR (100)  NOT NULL,
    [Send_Id]    INT             NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    FOREIGN KEY ([Send_Id]) REFERENCES [dbo].[EmailDB] ([Send_Id]),
    FOREIGN KEY ([Gmail_From]) REFERENCES [dbo].[LoginDB] ([Gmail_From])
);

CREATE TABLE [dbo].[LoginDB] (
    [Gmail_From]   NVARCHAR (100) NOT NULL,
    [Username]     VARCHAR (50)   NULL,
    [Password]     VARCHAR (50)   NOT NULL,
    [Confirm_pass] VARCHAR (50)   NULL,
    PRIMARY KEY CLUSTERED ([Gmail_From] ASC)
);


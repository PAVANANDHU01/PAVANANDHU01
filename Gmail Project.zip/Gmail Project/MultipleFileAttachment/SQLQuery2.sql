﻿CREATE TABLE EmailDB (
    Gmail_From VARCHAR(50) PRIMARY KEY NOT NULL,
    Gmail_To NVARCHAR(MAX),
    Subject NVARCHAR(MAX),
    Description NVARCHAR(MAX),
    Create_Date DATETIME
);

CREATE TABLE FileAttachment (
    Id INT PRIMARY KEY IDENTITY,
    FileName VARCHAR(MAX),
    FileData VARBINARY(MAX),
    Gmail_From VARCHAR(50),
    FOREIGN KEY (Gmail_From) REFERENCES EmailDB(Gmail_From)
);

CREATE TABLE [dbo].[LoginDB] (
    [Id]       INT            IDENTITY (1, 1) NOT NULL,
    [Gmail_From]    NVARCHAR (MAX) NOT NULL,
    [Username] VARCHAR (50)   NULL,
    [Password] VARCHAR (50)   NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

CREATE TABLE [dbo].[DriveDB] (
    [DId]            INT             IDENTITY (1, 1) NOT NULL,
    [Gmail_From]     NVARCHAR (100)  NOT NULL,
    [FileName]       VARCHAR (MAX)   NULL,
    [FileData]       VARBINARY (MAX) NULL,
    [Date_of_adding] DATETIME        NULL,
    PRIMARY KEY CLUSTERED ([DId] ASC),
    FOREIGN KEY ([Gmail_From]) REFERENCES [dbo].[LoginDB] ([Gmail_From])
);



select  a.[from], a. [to], a.id, b.id, b.email_id from emailDb a inner join fileAttachment b on a.id = b.Email_Id;


-- Find the name of the primary key constraint on the Id column of the EmailDB table
SELECT CONSTRAINT_NAME
FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS
WHERE TABLE_NAME = 'EmailDB' AND CONSTRAINT_TYPE = 'PRIMARY KEY';

-- Drop the primary key constraint using the actual constraint name
ALTER TABLE EmailDB
DROP CONSTRAINT Actual_Constraint_Name;

select* from EmailDB;
select* from FileAttachment;


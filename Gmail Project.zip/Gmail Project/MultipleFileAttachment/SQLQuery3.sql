﻿select* from LoginDB;
insert into LoginDB (Confirm_pass) values('123');
﻿using Microsoft.Reporting.WebForms;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication2
{
    public partial class WebForm1 : System.Web.UI.Page
    {
       
        protected void Page_Load(object sender, EventArgs e)
        {
            List<User> userList = new List<User>();
            if (!IsPostBack)
            {
                userList.Add(new User { UserID = 1, UserName = "Username1" });
                userList.Add(new User { UserID = 2, UserName = "Username2" });
                userList.Add(new User { UserID = 3, UserName = "Username3" });
                userList.Add(new User { UserID = 4, UserName = "Username4" });
                userList.Add(new User { UserID = 5, UserName = "Username5" });
                ReportViewer1.LocalReport.DataSources.Clear();
                ReportViewer1.LocalReport.DataSources.Add(new ReportDataSource("DataSet1", userList));
                ReportViewer1.LocalReport.ReportPath = Server.MapPath("Report1.rdlc");
                ReportViewer1.LocalReport.Refresh();
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using MultipleFileAttachment.Models;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;

namespace MultipleFileAttachment.Controllers
{
    public class EmailController : Controller
    {
        EmailDataEntities db = new EmailDataEntities();

        public ActionResult Index()
        {           
            string loggedInUserEmail = User.Identity.Name;       
            var emails = db.EmailDBs
                            .Include("FileAttachments")
                            .Where(e => e.Gmail_From == loggedInUserEmail)
                            .ToList();
            return View(emails);
        }

        public ActionResult ViewAttachment(int id)
        {
            var fileAttachment = db.FileAttachments.Find(id);
            if (fileAttachment == null)
            {
                return HttpNotFound();
            }
            return File(fileAttachment.FileData, "application/octet-stream", fileAttachment.FileName);
        }

        public ActionResult database()
        {
            return View(db.EmailDBs.ToList());
        }
        
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(EmailDB email, IEnumerable<HttpPostedFileBase> file)
        {
            if (User.Identity.IsAuthenticated) 
            {
                email.Gmail_From = User.Identity.Name;
                email.Create_Date = DateTime.Now;

                if (ModelState.IsValid)
                {
                    if (file != null && file.Any())
                    {
                        foreach (var files in file)
                        {
                            if (files != null && files.ContentLength > 0)
                            {
                                var fileName = Path.GetFileName(files.FileName);
                                var filePath = Path.Combine(Server.MapPath("~/Content/Files/"), fileName);
                                files.SaveAs(filePath);

                                var attachment = new FileAttachment
                                {
                                    FileName = fileName,
                                    FileData = System.IO.File.ReadAllBytes(filePath),
                                    Gmail_From = email.Gmail_From
                                };
                                db.FileAttachments.Add(attachment);
                            }
                        }
                    }             
                    db.EmailDBs.Add(email);
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }
            }
            else
            {               
                return RedirectToAction("Login", "Account");
            }

            return View(email);
        }

        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            EmailDB regis = db.EmailDBs.Find(id);
            if (regis == null)
            {
                return HttpNotFound();
            }
            return View(regis);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            EmailDB regis = db.EmailDBs.Find(id);
            db.EmailDBs.Remove(regis);
            db.SaveChanges();
            return RedirectToAction("database");
        }
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}

﻿using MultipleFileAttachment.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace MultipleFileAttachment.Controllers
{
    public class DriveController : Controller
    {
        EmailDataEntities d = new EmailDataEntities();
        // GET: Drive
        public ActionResult Index()
        {
            string loggedInUserEmail = User.Identity.Name;
            var emails = d.DriveDBs.Where(e => e.Gmail_From == loggedInUserEmail).ToList();
            return View(emails.ToList());            
        }

        public ActionResult create()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult create(DriveDB drive, IEnumerable<HttpPostedFileBase> file)
        {
            if (User.Identity.IsAuthenticated)
            {
                drive.Gmail_From = User.Identity.Name;
                
                if (ModelState.IsValid)
                {
                    if (file != null && file.Any())
                    {
                        foreach (var files in file)
                        {
                            if (files != null && files.ContentLength > 0)
                            {
                                var fileName = Path.GetFileName(files.FileName);
                                var filePath = Path.Combine(Server.MapPath("~/Content/drivefiles/"), fileName);
                                files.SaveAs(filePath);

                                var drives = new DriveDB
                                {
                                    FileName = fileName,
                                    FileData = System.IO.File.ReadAllBytes(filePath),
                                    Gmail_From = drive.Gmail_From
                                };
                                drives.Date_of_adding = DateTime.Now;
                                d.DriveDBs.Add(drives);
                                d.SaveChanges();
                            }
                        }
                    }                                                           
                }
            }
            return RedirectToAction("Index");
        }

        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            DriveDB del = d.DriveDBs.Find(id);
            if (del == null)
            {
                return HttpNotFound();
            }
            d.DriveDBs.Remove(del);
            d.SaveChanges();
            return View();
        }
    }
}
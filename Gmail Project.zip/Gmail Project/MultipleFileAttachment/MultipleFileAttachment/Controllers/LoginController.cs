﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MultipleFileAttachment.Models;
using System.Web.Security;

namespace MultipleFileAttachment.Controllers
{
    public class LoginController : Controller
    {
        EmailDataEntities d = new EmailDataEntities();
        // GET: Login
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Register(LoginDB user)
        {
            if (ModelState.IsValid)
            {
                var check = d.LoginDBs.Where(m => m.Gmail_From == user.Gmail_From).FirstOrDefault();
                if (check == null)
                {
                    if (user.Password == user.Confirm_pass)
                    {
                        d.LoginDBs.Add(user);
                        d.SaveChanges();
                        ViewBag.Message = "Register Successfully";
                    }
                    else
                    {
                        ViewBag.Message = "Enter valid password";
                        return View();
                    }
                }
                else
                {
                    ViewBag.Message = "Gmail ID Already Registered";
                    return View();
                }
            }
            return RedirectToAction("Login");

        }

        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Login(LoginDB user)
        {
            if (ModelState.IsValid)
            {
                bool IsValid = d.LoginDBs.Any(u => u.Gmail_From == user.Gmail_From.ToString() && u.Password == user.Password.ToString());
                if (IsValid)
                {
                    FormsAuthentication.SetAuthCookie(user.Gmail_From, false);

                    return RedirectToAction("Create", "Email");
                }
                else
                {
                    ViewBag.Message = "Enter Valid Password";
                    return View();
                }
            }
            return View();
        }

        public ActionResult ForgotPassword()
        {
            return View();
        }

        [HttpPost]
        public ActionResult ForgotPassword(string emailOrPhone)
        {
            return RedirectToAction("ResetPassword");
        }

        public ActionResult OTPProcessing(string email, string otp)
        {
            var user = d.LoginDBs.FirstOrDefault(u => u.Gmail_From == email);
            if (user != null)
            {
                if (string.IsNullOrEmpty(otp))
                {
                    Random random = new Random();
                    int otpNumber = random.Next(100000, 999999);
                    string generatedOtp = otpNumber.ToString();

                    Session["OTP"] = generatedOtp;
                    TempData["EmailOrPhone"] = email;
                    // Send OTP via email or SMS (you need to implement this part)

                    //ViewBag.Message = generatedOtp;                   

                    return Content("OTP sent successfull ! Your OTP is: " + generatedOtp);
                }
                else
                {
                    string storedOtp = Session["OTP"] as string;
                    if (otp == storedOtp)
                    {
                        return Content("OTP verification successfull.");
                    }
                    else
                    {
                        ModelState.AddModelError("", "Invalid OTP.");
                        return View();
                    }
                }
            }
            else
            {
                ModelState.AddModelError("", "User not found.");
                return View();
            }
        }
        public ActionResult ResetPassword()
        {
            return View();
        }

        [HttpPost]
        public ActionResult ResetPassword(string newPassword, string confirmPassword)
        {
            string email = TempData["EmailOrPhone"].ToString();
            var user = d.LoginDBs.FirstOrDefault(u => u.Gmail_From == email);
            if (user != null)
            {
                if (newPassword != confirmPassword)
                {
                    ModelState.AddModelError("", "The new password and confirm password do not match.");
                    return View();
                }

                user.Password = newPassword;                
                d.SaveChanges();
                TempData["Message"] = "Password reset successful. You can now login with your new password.";
                return RedirectToAction("Login", "Login");
            }
            else
            {
                ModelState.AddModelError("", "User not found.");
                return View();
            }
        }

        public ActionResult Signout()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Login");
        }

    }
}
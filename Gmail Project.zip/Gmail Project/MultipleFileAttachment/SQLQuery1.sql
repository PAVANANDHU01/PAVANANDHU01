﻿CREATE TABLE [dbo].[EmailDB] (
    [Send_Id]     INT            IDENTITY (1, 1) NOT NULL,
    [Gmail_From]  NVARCHAR (100) NOT NULL,
    [Gmail_To]    NVARCHAR (MAX) NULL,
    [Subject]     NVARCHAR (MAX) NULL,
    [Description] NVARCHAR (MAX) NULL,
    [Create_Date] DATETIME       NULL,
    PRIMARY KEY CLUSTERED ([Send_Id] ASC),
    FOREIGN KEY ([Gmail_From]) REFERENCES [dbo].[LoginDB] ([Gmail_From])
);

CREATE TABLE [dbo].[FileAttachment] (
    [Id]         INT             IDENTITY (1, 1) NOT NULL,
    [FileName]   VARCHAR (MAX)   NULL,
    [FileData]   VARBINARY (MAX) NULL,
    [Gmail_From] NVARCHAR (100)  NOT NULL,
    [Send_Id]    INT             NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    FOREIGN KEY ([Send_Id]) REFERENCES [dbo].[EmailDB] ([Send_Id]),
    FOREIGN KEY ([Gmail_From]) REFERENCES [dbo].[LoginDB] ([Gmail_From])
);


CREATE TABLE [dbo].[LoginDB] (
    [Gmail_From] NVARCHAR (100) NOT NULL,
    [Username]   VARCHAR (50)   NULL,
    [Password]   VARCHAR (50)   NOT NULL,
    PRIMARY KEY CLUSTERED ([Gmail_From] ASC)
);

select * from LoginDB;
select * from FileAttachment;
select * from EmailDB;

alter table EmailDB drop column Gmail_from

truncate table FileAttachment;

truncate table EmailDB;

delete from EmailDB
where Send_Id=35;

delete from FileAttachment.0
where Send_Id=35;

select FileData from FileAttachment;

delete from FileAttachment where Send_Id= 27;
delete from EmailDB where Send_Id = 27;

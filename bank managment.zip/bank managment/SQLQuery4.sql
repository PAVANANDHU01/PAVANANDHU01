﻿truncate table AccountDB;
truncate table CustomerDB;

select * from AccountDB;
select* from CustomerDB;
select * from TransactionDB;
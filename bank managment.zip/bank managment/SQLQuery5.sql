﻿select* from AccountDB;
select* from TransactionDB;
select* from CustomerDB;
select* from UserDB;
select* from CustomerDetails;
select* from BalanceDb;
select* from EmployeeDB;

delete from CustomerDetails where CDid=10;
delete from CustomerDB where CustomerID=3;
delete from AccountDB where Aid=14;
delete from BalanceDb where Id=5;
delete from TransactionDB where TransactionID=1;
delete from AccountDB;

truncate table TransactionDB;
truncate table AccountDB;
truncate table CustomerDB;
truncate table UserDB;
truncate table CustomerDetails;
truncate table BalanceDb;

update TransactionDB
Set Withdrawl = 0 , Deposit = 0;

INSERT INTO [dbo].[TransactionDB] ([AccountNumber], [Name],[MobileNo], [AccountBalance], [Deposit], [Withdrawl], [TransactionDate]) VALUES (N'8874368745', N'pavan',N'6380394146',CAST(0.00 AS Decimal(18, 2)), CAST(0.00 AS Decimal(18, 2)), CAST(0.00 AS Decimal(18, 2)), N'2024-03-08 12:07:57')
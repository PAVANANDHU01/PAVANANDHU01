﻿using bank_managment_system.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace bank_managment_system.Controllers
{
    public class EmployeeController : Controller
    {
        bank_managmentEntities d = new bank_managmentEntities();
        // GET: Employee
        public ActionResult Index()
        {
            return View(d.EmployeeDBs.ToList());
        }

        public ActionResult create()
        {
            return View();
        }
        [HttpPost]
        public ActionResult create(EmployeeDB employee)
        {
            if (ModelState.IsValid)
            {
                var check = d.EmployeeDBs.Where(m => m.Phone == employee.Phone && m.Username == employee.Username).FirstOrDefault();
                if (check == null)
                {
                    if (employee.Name != null && employee.Phone != null&&employee.Password!=null&&employee.Role!=null)
                    {
                        d.EmployeeDBs.Add(employee);
                        d.SaveChanges();
                        ModelState.AddModelError("", "Saved successully");
                    }
                    else
                    {
                        ModelState.AddModelError("", "Please Fill All The Fields");
                    }
                }
                else
                {
                    ModelState.AddModelError("", "Username Or MobileNumber Already Exits");
                }
            }
            return View();
        }  

        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Login(EmployeeDB emp)
        {
            if (ModelState.IsValid)
            {
                bool isvalid = d.EmployeeDBs.Any(u => u.Username == emp.Username.ToString() && u.Password == emp.Password.ToString());
                if (isvalid)
                {
                    FormsAuthentication.SetAuthCookie(emp.Username, false);
                    Session["Role"] = 1;
                    return RedirectToAction("cusdelindex", "User");
                }
                else
                {
                    ModelState.AddModelError("", "Invalid Username Or Password");
                }
            }
            return View();
        }

        public ActionResult Signout()
        {
            FormsAuthentication.SignOut();
            Session["Role"] = null;
            Session["user"] = null;
            return View();
        }
       
    }
}
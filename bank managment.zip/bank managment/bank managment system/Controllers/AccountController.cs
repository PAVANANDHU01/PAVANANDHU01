﻿using bank_managment_system.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace bank_managment_system.Controllers
{
    public class AccountController : Controller
    {
        bank_managmentEntities d = new bank_managmentEntities();
        // GET: Account
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult create()
        {
            ViewBag.CustomerID = new SelectList(d.CustomerDBs, "CustomerID", "Name");
            return View();
        }
        [HttpPost]
        public ActionResult create(AccountDB account)
        {
            if (ModelState.IsValid)
            {
                if (account.MobileNo != null&&account.AccountType!=null)
                {                   
                    d.AccountDBs.Add(account);
                    account.Date_acc = DateTime.Now;
                    ViewBag.CustomerID = new SelectList(d.CustomerDBs, "CustomerID", "Name");
                    d.SaveChanges();
                    ModelState.AddModelError("", "Saved successfully");
                }
                else
                {
                    ViewBag.CustomerID = new SelectList(d.CustomerDBs, "CustomerID", "Name");
                    ModelState.AddModelError("", "Filled to save");
                }
            }
            ViewBag.CustomerID = new SelectList(d.CustomerDBs, "CustomerID", "Name");
            return View();
        }

        public ActionResult balanceindex()
        {
            return View(d.BalanceDbs.ToList());
        }
        public ActionResult balance()
        {
            ViewBag.AccountNumber = new SelectList(d.AccountDBs, "Aid", "AccountNUmber");
            return View();
        }
        [HttpPost]
        public ActionResult balance(BalanceDb balance)
        {
            if (ModelState.IsValid)
            {
                if (balance.Name != null && balance.MobileNo != null)
                {
                    d.BalanceDbs.Add(balance);
                    d.SaveChanges();
                    ModelState.AddModelError("", "Saved Successfully");
                }
                else
                {
                    ModelState.AddModelError("", "failed to save");
                }
            }
            ViewBag.AccountNumber = new SelectList(d.AccountDBs, "Aid", "AccountNUmber");
            return View();
        }

    }
}
﻿using bank_managment_system.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace bank_managment_system.Controllers
{
    public class MoneytransController : Controller
    {
        bank_managmentEntities d = new bank_managmentEntities();
        // GET: Moneytrans
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult moneytran()
        {
            return View();
        }
        [HttpPost]
        public ActionResult moneytran(int id)
        {
            return View();
        }
    }
}
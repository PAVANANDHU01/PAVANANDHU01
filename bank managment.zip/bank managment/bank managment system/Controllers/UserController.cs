﻿using bank_managment_system.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace bank_managment_system.Controllers
{
    public class UserController : Controller
    {
        bank_managmentEntities d = new bank_managmentEntities();
        // GET: User
        public ActionResult Register()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Register(UserDB user)
        {
            if (ModelState.IsValid)
            {
                var check = d.UserDBs.Where(m => m.PhoneNo == user.PhoneNo).FirstOrDefault();
                if (check == null)
                {
                    if (user.Username != null && user.PhoneNo != null && user.Email != null)
                    {
                        var g = d.AccountDBs.Where(m => m.MobileNo == user.PhoneNo).FirstOrDefault();
                        if (g != null)
                        {
                            if(user.Password==user.ConfirmPass)
                            {
                                d.UserDBs.Add(user);
                                d.SaveChanges();
                                ModelState.AddModelError("", "Register Succesfully");
                            }
                            else
                            {
                                ModelState.AddModelError("", "Please Enter Valid Password And Confirm Password");
                            }                     
                        }
                        else
                        {
                            ModelState.AddModelError("", "Still Your Account Don't Created In Bank Try Again Later");
                        }
                    }
                    else
                    {
                        ModelState.AddModelError("", "Please Fill All The Fields");
                    }
                }
                else
                {
                    ModelState.AddModelError("", "MobileNumber  Already Exists");
                }
            }
            return View();
        }
        
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Login(UserDB user)
        {
            if (ModelState.IsValid)
            {
                bool IsValid = d.UserDBs.Any(m => m.PhoneNo == user.PhoneNo.ToString() && m.Password == user.Password.ToString());
                if (IsValid)
                {
                    FormsAuthentication.SetAuthCookie(user.PhoneNo, false);
                    Session["user"] = 2;
                    return RedirectToAction("SendMoney", "Transaction");
                }
                else
                {
                    ModelState.AddModelError("", "Invalid Username Or Password");
                }
            }
            return View();
        }



        public ActionResult accountview()
        {
            return View(d.AccountDBs.ToList());
        }

        public ActionResult AccCreate(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            CustomerDetail cus = d.CustomerDetails.Find(id);
            var data = d.AccountDBs.Where(c => c.MobileNo == cus.MobileNo).FirstOrDefault();
            if (data != null)
            {
                TempData["Message"] = "Account Already Exists";
                return RedirectToAction("cusdelindex");
            }
            AccountDB db = new AccountDB();
            db.Name = cus.Name;
            db.Age = cus.Age;
            db.Address = cus.Address;
            db.MobileNo = cus.MobileNo;
            db.Panno = cus.PanNo;
            db.District = cus.District;
            db.Pincode = cus.Pincode;
            if (db == null)
            {
                return HttpNotFound();
            }
            return View(db);
        }
        [HttpPost]
        public ActionResult AccCreate(AccountDB acc)
        {
            if (ModelState.IsValid)
            {
                if (acc.AccountNumber != null && acc.AccountType != null)
                {
                    d.AccountDBs.Add(acc);
                    acc.Date_acc = DateTime.Now;
                    BalanceDb Balance = new BalanceDb();
                    Balance.Name = acc.Name;
                    Balance.AccountNumber = acc.AccountNumber;
                    Balance.MobileNo = acc.MobileNo;
                    Balance.TotalBalance = 0;
                    d.BalanceDbs.Add(Balance);
                    d.SaveChanges();
                    return RedirectToAction("accountview");
                }
                else
                {
                    ModelState.AddModelError("", "Please Fill All The Fields");
                }
            }
            return View();
        }
       
        public ActionResult cusdelindex()
        {
            return View(d.CustomerDetails.ToList());
        }
        public ActionResult CustomerDetails()
        {
            return View();
        }
        [HttpPost]
        public ActionResult CustomerDetails(CustomerDetail cusdel)
        {
            if (ModelState.IsValid)
            {
                var check = d.CustomerDetails.Where(m => m.MobileNo == cusdel.MobileNo).FirstOrDefault();
                if (check == null)
                {
                    if (cusdel.Name != null && cusdel.MobileNo != null && cusdel.PanNo != null)
                    {
                        if (cusdel.Name != null && cusdel.MobileNo != null)
                        {
                            d.CustomerDetails.Add(cusdel);
                            d.SaveChanges();
                            ModelState.AddModelError("", "Your Account Will be Created in Few Hours Please Wait");
                        }
                        else
                        {
                            ModelState.AddModelError("", "Failed To Register");
                            return View();
                        }
                    }                    
                    else
                    {
                        ModelState.AddModelError("", "Please Fill All The Fields");
                    }
                }
                else
                {
                    ModelState.AddModelError("", "MobileNumber Already Registered");
                }
            }
            return View();
        }

        public ActionResult edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            AccountDB account = d.AccountDBs.Find(id);
            if (account == null)
            {
                return HttpNotFound();
            }
            return View(account);
        }
        [HttpPost]
        public ActionResult edit(AccountDB act)
        {
            if (ModelState.IsValid)
            {
                d.Entry(act).State = EntityState.Modified;
                d.SaveChanges();
            }
            return RedirectToAction("accountview");
        }

        public ActionResult delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            AccountDB account = d.AccountDBs.Find(id);
            if (account == null)
            {
                return HttpNotFound();
            }
            return View(account);
        }
        [HttpPost]
        public ActionResult delete(int id)
        {
            AccountDB account = d.AccountDBs.Find(id);
            d.AccountDBs.Remove(account);
            d.SaveChanges();
            return RedirectToAction("accountview");
        }

        public ActionResult Signout()
        {
            FormsAuthentication.SignOut();
            Session["Role"] = null;
            Session["user"] = null;
            return RedirectToAction("Login");
        }

    }
}
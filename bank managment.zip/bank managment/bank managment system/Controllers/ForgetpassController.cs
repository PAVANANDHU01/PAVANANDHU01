﻿using bank_managment_system.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace bank_managment_system.Controllers
{
    public class ForgetpassController : Controller
    {
        bank_managmentEntities d = new bank_managmentEntities();
        // GET: Forgetpass
        public ActionResult ForgotPassword()
        {
            return View();
        }                   
        [HttpPost]
        public ActionResult ForgotPassword(string emailOrPhone)
        {            
            return RedirectToAction("ResetPassword");
        }
      
        public ActionResult OTPProcessing(string phoneno, string otp)
        {
            var user = d.UserDBs.FirstOrDefault(u => u.PhoneNo == phoneno);
            if (user != null)
            {
                if (string.IsNullOrEmpty(otp))
                {
                    Random random = new Random();
                    int otpNumber = random.Next(100000, 999999);
                    string generatedOtp = otpNumber.ToString();
                    Session["OTP"] = generatedOtp;
                    TempData["EmailOrPhone"] = phoneno;
                    return Content("OTP sent successfull ! Your OTP is: " + generatedOtp);
                }
                else
                {
                    string storedOtp = Session["OTP"] as string;
                    if (otp == storedOtp)
                    {
                        return Content("OTP verification successfull.");
                    }
                    else
                    {
                        ModelState.AddModelError("", "Invalid OTP.");
                        return View();
                    }
                }
            }
            else
            {
                ModelState.AddModelError("", "User not found.");
                return View();
            }
        }        
      
        public ActionResult ResetPassword()
        {
            return View();
        }
        [HttpPost]
        public ActionResult ResetPassword(string newPassword, string confirmPassword)
        {
            string email = TempData["EmailOrPhone"].ToString();
            var user = d.UserDBs.FirstOrDefault(u => u.PhoneNo == email);
            if (user != null)
            {
                if (newPassword == confirmPassword&&newPassword!=""&&confirmPassword!="")
                {
                    user.Password = newPassword;
                    user.ConfirmPass = confirmPassword;
                    d.SaveChanges();
                    TempData["Message"] = "Password reset successful. You can now login with your new password.";
                    return RedirectToAction("Login", "User");                    
                }
                else
                {
                    ModelState.AddModelError("", "Enter valid password");
                    return View();
                }                
            }
            else
            {
                ModelState.AddModelError("", "User not found.");
                return View();
            }
        }

        public ActionResult Signout()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Login");            
        }

    }
}
﻿using bank_managment_system.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace bank_managment_system.Controllers
{
    public class CustomerController : Controller
    {
        bank_managmentEntities d = new bank_managmentEntities();
        // GET: Customer
        public ActionResult Index()
        {
            return View(d.CustomerDBs.ToList());
        }    

        public ActionResult create()
        {
            return View();
        }
        [HttpPost]
        public ActionResult create(CustomerDB customer)
        {
            if (ModelState.IsValid)
            {
                d.CustomerDBs.Add(customer);
                customer.Date_cus = DateTime.Now;           
                d.SaveChanges();
                ModelState.AddModelError("", "Saved Successfully");
            }
            return View();
        }
    }
}
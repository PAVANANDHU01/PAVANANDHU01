﻿using bank_managment_system.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using Newtonsoft.Json;

namespace bank_managment_system.Controllers
{
    public class TransactionController : Controller
    {
        bank_managmentEntities d = new bank_managmentEntities();
        // GET: Transaction
        public ActionResult Index()
        {
            string loggedInUserEmail = User.Identity.Name;
            var emails = d.TransactionDBs.Where(e => e.MobileNo == loggedInUserEmail).ToList();
            return View(emails);
        }

        public ActionResult alltrans()
        {
            return View(d.TransactionDBs.ToList());
        }

        public ActionResult CustomerTransaction()
        {
            return View();
        }
        [HttpPost]
        public ActionResult CustomerTransaction(string value)
         {
            var m = d.AccountDBs.FirstOrDefault(x => x.MobileNo == value);
            var n = d.AccountDBs.FirstOrDefault(x => x.AccountNumber == value);
            if (m != null || n!=null)
            {
                List<string> accdetails = new List<string>();
                if (m != null)
                {
                    accdetails.Add(m.AccountNumber);
                    accdetails.Add(m.Name);
                }
                else
                {
                    accdetails.Add(n.AccountNumber);
                    accdetails.Add(n.Name);
                }
                return Json(accdetails, JsonRequestBehavior.AllowGet);
            }            
            else
            {                
                return Content("Account Doesn't Exist");
            }
        }        
       
        public ActionResult Deposit(string phn)
        {
            var data = phn;
            var m = d.AccountDBs.FirstOrDefault(x => x.MobileNo == data || x.AccountNumber == data);

            if (m != null)
            {
                TransactionDB db = new TransactionDB();
                db.AccountNumber = m.AccountNumber;
                db.Name = m.Name;
                db.MobileNo = m.MobileNo;
                return View(db);
            }
            return View();
        }
        [HttpPost]
        public ActionResult Deposit(TransactionDB trans)
        {
            if (ModelState.IsValid)
            {
                var data = trans.MobileNo;
                var account = d.AccountDBs.FirstOrDefault(x => x.MobileNo == data);

                if (account != null && trans.Deposit != null)
                {
                    var currentBalance = d.BalanceDbs.Where(x => x.MobileNo == account.MobileNo).FirstOrDefault();
                    currentBalance.TotalBalance += trans.Deposit;
                    d.Entry(currentBalance).State = EntityState.Modified;
                    TransactionDB transaction = new TransactionDB
                    {
                        AccountNumber = account.AccountNumber,
                        Name = account.Name,
                        MobileNo = account.MobileNo,
                        AccountBalance = currentBalance.TotalBalance,
                        Trans_type = "Self",
                        Deposit = trans.Deposit,
                        TransactionDate = DateTime.Now
                    };

                    transaction.Withdrawl = 0;
                    d.TransactionDBs.Add(transaction);
                    d.SaveChanges();

                    ModelState.AddModelError("", "Transaction Deposit Successful");
                    return View();
                }
                else
                {
                    ModelState.AddModelError("", "Transaction Failed");
                }
            }
            return View(trans);
        }
               
        public ActionResult Withdrawl(string phn)
        {
            var data = phn;
            var account = d.AccountDBs.FirstOrDefault(x => x.MobileNo == data || x.AccountNumber == data);
            if (account != null)
            {
                TransactionDB transaction = new TransactionDB();
                transaction.AccountNumber = account.AccountNumber;
                transaction.Name = account.Name;
                transaction.MobileNo = account.MobileNo;
                return View(transaction);
            }
            return View();
        }
        [HttpPost]
        public ActionResult Withdrawl(TransactionDB with)
        {
            if (ModelState.IsValid)
            {
                var data = with.MobileNo;
                var account = d.AccountDBs.FirstOrDefault(x => x.MobileNo == data);

                if (account != null && with.Withdrawl != null)
                {
                    var currentBalance = d.BalanceDbs.Where(x => x.MobileNo == account.MobileNo).FirstOrDefault();

                    if (with.Withdrawl <= currentBalance.TotalBalance)
                    {
                        currentBalance.TotalBalance -= with.Withdrawl;
                        d.Entry(currentBalance).State = EntityState.Modified;
                        TransactionDB transaction = new TransactionDB
                        {
                            AccountNumber = account.AccountNumber,
                            Name = account.Name,
                            MobileNo = account.MobileNo,
                            Trans_type = "Self",
                            AccountBalance = currentBalance.TotalBalance,
                            Withdrawl = with.Withdrawl,
                            TransactionDate = DateTime.Now
                        };
                        transaction.Deposit = 0;
                        d.TransactionDBs.Add(transaction);
                        d.SaveChanges();

                        ModelState.AddModelError("", "Transaction Withdrawal Successful");
                        return View();
                    }
                    else
                    {
                        ModelState.AddModelError("", "Insufficient balance for withdrawal");
                    }
                }
                else
                {
                    ModelState.AddModelError("", "Transaction Failed");
                }
            }
            return View(with);
        }

        public ActionResult SendMoney()
        {
            var data = User.Identity.Name;
            var account = d.AccountDBs.FirstOrDefault(x => x.MobileNo == data);

            if (account != null)
            {
                TransactionDB transaction = new TransactionDB();
                transaction.Name = account.Name;
                transaction.MobileNo = account.MobileNo;
                return View(transaction);
            }
            return View();
        }

        public string getName(long number)
        {            
            var num = number.ToString();
            var username = d.UserDBs.Where(x => x.PhoneNo == num).FirstOrDefault();
            if (username != null)
            {
                return username.Username;
            }
            return "Account doesn't Exist";
        }
        
        public ActionResult sendmony(sendmoney send)
        {
            if (ModelState.IsValid)
            {
                if (send != null)
                {
                    var senderaccount = d.AccountDBs.FirstOrDefault(x => x.MobileNo == send.MobileNo);
                    var receiveraccount = d.AccountDBs.FirstOrDefault(x => x.MobileNo == send.RecepientNo);

                    var currentBalancesender = d.BalanceDbs.Where(x => x.MobileNo == senderaccount.MobileNo).FirstOrDefault();
                    var currentBalancereciever = d.BalanceDbs.Where(x => x.MobileNo == send.RecepientNo).FirstOrDefault();
                    if (send.Withdrawl < currentBalancesender.TotalBalance)
                    {
                        DateTime currentdate = DateTime.Now.Date;
                        int limit = 10000;
                        var checklimit = d.TransactionDBs.Where(x => DbFunctions.TruncateTime(x.TransactionDate) == currentdate && x.MobileNo == send.MobileNo).Sum(x => x.Withdrawl);
                        if (checklimit >= limit || send.Withdrawl > limit)
                        {                            
                            return Content("Transaction Limit Reached");
                        }
                        
                        currentBalancesender.TotalBalance -= send.Withdrawl;
                        currentBalancereciever.TotalBalance += send.Withdrawl;
                        
                        TransactionDB sndtransaction = new TransactionDB
                        {
                            AccountNumber = senderaccount.AccountNumber,
                            Name = senderaccount.Name,
                            MobileNo = senderaccount.MobileNo,
                            Trans_type = send.RecepientNo + "(" + receiveraccount.Name + ")",
                            AccountBalance = currentBalancesender.TotalBalance,
                            Withdrawl = send.Withdrawl,
                            Deposit = 0,
                            TransactionDate = DateTime.Now
                        };
                        TransactionDB rectransact = new TransactionDB
                        {
                            AccountNumber = receiveraccount.AccountNumber,
                            Name = receiveraccount.Name,
                            MobileNo = receiveraccount.MobileNo,
                            Trans_type = send.MobileNo + "(" + send.Name + ")",
                            AccountBalance = currentBalancereciever.TotalBalance,
                            Deposit = send.Withdrawl,
                            Withdrawl = 0,
                            TransactionDate = DateTime.Now
                        };
                        d.TransactionDBs.Add(sndtransaction);
                        d.TransactionDBs.Add(rectransact);
                        d.SaveChanges();
                        return Content("Amount Sent Successfully");
                    }
                    else
                    {
                        return Content("Insufficient balance");
                    }
                }
            }
            return View();
        }
        
        public ActionResult delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            TransactionDB trans = d.TransactionDBs.Find(id);
            d.TransactionDBs.Remove(trans);
            d.SaveChanges();
            return RedirectToAction("Index");
        }
       
        public ActionResult checkbal()
        {
            string loggedInUserEmail = User.Identity.Name;
            var bal = d.BalanceDbs.Where(e => e.MobileNo == loggedInUserEmail).ToList();
            return View(bal);
        }
       
        public ActionResult checkAccountBalance()
        {
            var data = User.Identity.Name;
            var accountdetails = d.AccountDBs.Where(x => x.MobileNo == data).FirstOrDefault();
            if (accountdetails != null)
            {
                ViewBag.AccountNumber = accountdetails.AccountNumber;
                ViewBag.AccountHolder = accountdetails.Name;
            }
            return View();
        }        

        public ActionResult AccountBalance(string password)
        {
            var data = User.Identity.Name;
            var accountdetails = d.UserDBs.Where(x => x.Password == password && x.PhoneNo == data).FirstOrDefault();
            if (accountdetails != null)
            {
                var balance = d.BalanceDbs.Where(x => x.MobileNo == data).FirstOrDefault();
                return Content(balance.TotalBalance.ToString());
            }
            return Content("Password Invalid");
        }

        public void setlimit(string phn)
        {
            var trans = d.TransactionDBs.Where(x => x.MobileNo == phn).FirstOrDefault();
        }

        public ActionResult CalculateWithdrawalTotal(string data)
        {            
            DateTime currentDate = DateTime.Now.Date; // Get the current date without the time part
                        
            var checklimit = d.TransactionDBs
        .Where(x => DbFunctions.TruncateTime(x.TransactionDate) == currentDate && x.MobileNo == data)
        .Sum(x => x.Withdrawl);
            
            return View(checklimit);
        }
                
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace bank_managment_system.Models
{
    public class sendmoney
    {
        public string Name { get; set; }
        public string MobileNo { get; set; }
        public string RecepientNo { get; set; } // This property corresponds to the input field
        public string RecepientName { get; set; } // Add this property to hold the recipient name temporarily
        [Required]
        public decimal Withdrawl { get; set; }
    }
}
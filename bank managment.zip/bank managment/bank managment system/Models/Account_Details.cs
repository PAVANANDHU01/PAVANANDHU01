﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace bank_managment_system.Models
{
    public class Account_Details
    {
        public string AccountNumber { get; set; }
        public string Name { get; set; }
        public string AccountType { get; set; }
        public string Mobile_no { get; set; }
        public string Password { get; set; }
        public Nullable<decimal> Balance { get; set; }
    }
}
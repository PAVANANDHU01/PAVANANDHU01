﻿CREATE TABLE UsersDB (
    UserID INT identity(1,1) PRIMARY KEY,
    Username VARCHAR(50) NOT NULL UNIQUE,
    Password VARCHAR(255) NOT NULL,
    Email VARCHAR(100) NOT NULL UNIQUE,
    FullName VARCHAR(100) NOT NULL,
    RegistrationDate Datetime
);

CREATE TABLE AccountsDB (
    AccountID INT identity(1,1) PRIMARY KEY,
    UserID INT,
    AccountType VARCHAR(20) NOT NULL CHECK (AccountType IN ('Savings', 'Checking', 'Credit Card')),
    Balance DECIMAL(10, 2) NOT NULL DEFAULT 0,
    FOREIGN KEY (UserID) REFERENCES UsersDB(UserID)
);

CREATE TABLE TransactionsDB (
    TransactionID INT IDENTITY(1,1) PRIMARY KEY,
    AccountID INT,
    Amount DECIMAL(10, 2) NOT NULL,
    TransactionType VARCHAR(20) NOT NULL CHECK (TransactionType IN ('Deposit', 'Withdrawal', 'Transfer')),
    Description TEXT,
    TransactionDate datetime,
    FOREIGN KEY (AccountID) REFERENCES AccountsDB(AccountID)
);

CREATE TABLE TransactionCategories (
    CategoryID INT identity(1,1) PRIMARY KEY,
    CategoryName VARCHAR(50) NOT NULL
);

CREATE TABLE TransactionCategoryMapping (
    TransactionID INT,
    CategoryID INT,
    FOREIGN KEY (TransactionID) REFERENCES TransactionsDB(TransactionID),
    FOREIGN KEY (CategoryID) REFERENCES TransactionCategories(CategoryID)
);

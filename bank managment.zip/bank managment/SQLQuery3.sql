﻿CREATE TABLE CustomerDB (
    CustomerID INT identity(1,1) PRIMARY KEY,
    Name VARCHAR(100),
    Address VARCHAR(255),
    Email VARCHAR(100),
    Phone VARCHAR(20),
	Date_cus datetime
);

CREATE TABLE AccountDB (
    AccountNumber INT PRIMARY KEY,
    CustomerID INT,
    AccountType VARCHAR(20),
    Balance DECIMAL(15, 2),
	Date_acc datetime,
    FOREIGN KEY (CustomerID) REFERENCES CustomerDB(CustomerID)
);

CREATE TABLE TransactionDB (
    TransactionID INT identity(1,1) PRIMARY KEY,
    AccountNumber INT,
    TransactionType VARCHAR(20),
    Amount DECIMAL(15, 2),
    TransactionDate datetime,
    FOREIGN KEY (AccountNumber) REFERENCES AccountDB(AccountNumber)
);

CREATE TABLE UserDB (
    UserID INT identity(1,1) PRIMARY KEY,
    Username VARCHAR(50) UNIQUE NOT NULL,
    [Password] VARCHAR(255) NOT NULL,
    Email VARCHAR(100) UNIQUE NOT NULL
);


CREATE TABLE [dbo].[CustomerDetails]
(
	[CDid] INT identity(1,1) NOT NULL PRIMARY KEY, 
    [Name] VARCHAR(50) NULL, 
    [Age] INT NULL, 
    [Address] VARCHAR(50) NULL, 
    [MobileNo] VARCHAR(50) NULL, 
    [PanNo] VARCHAR(50) NULL, 
    [District] VARCHAR(50) NULL, 
    [Pincode] VARCHAR(50) NULL
)
CREATE TABLE Loans (
    LoanID INT PRIMARY KEY,
    CustomerID INT,
    LoanType VARCHAR(50),
    Amount DECIMAL(15, 2),
    InterestRate DECIMAL(5, 2),
    TermMonths INT,
    Status VARCHAR(20),
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
);

CREATE TABLE EmployeeDB (
    EmployeeID INT identity(1,1) PRIMARY KEY,
    Name VARCHAR(100),
    Email VARCHAR(100),
    Phone VARCHAR(20)
);


select* from UserDB;
﻿CREATE TABLE [dbo].[AccountDB] (
    [Aid]           INT           IDENTITY (1, 1) NOT NULL,
    [AccountNumber] NVARCHAR (50) NOT NULL,
    [Name]          VARCHAR (50)  NULL,
    [Age]           INT           NULL,
    [Address]       VARCHAR (50)  NULL,
    [MobileNo]      VARCHAR (50)  NULL,
    [Panno]         VARCHAR (50)  NULL,
    [District]      VARCHAR (50)  NULL,
    [Pincode]       VARCHAR (50)  NULL,
    [AccountType]   VARCHAR (20)  NULL,
    [Date_acc]      DATETIME      NULL,
    CONSTRAINT [PK_AccountDB] PRIMARY KEY CLUSTERED ([Aid] ASC)
);

CREATE TABLE [dbo].[BalanceDb] (
    [Id]            INT             IDENTITY (1, 1) NOT NULL,
    [AccountNumber] VARCHAR (50)    NULL,
    [Name]          VARCHAR (50)    NULL,
    [MobileNo]      VARCHAR (50)    NULL,
    [TotalBalance]  DECIMAL (18, 2) NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

CREATE TABLE [dbo].[CustomerDB] (
    [CustomerID] INT           IDENTITY (1, 1) NOT NULL,
    [Name]       VARCHAR (100) NULL,
    [Address]    VARCHAR (255) NULL,
    [Email]      VARCHAR (100) NULL,
    [Phone]      VARCHAR (20)  NULL,
    [Date_cus]   DATETIME      NULL,
    PRIMARY KEY CLUSTERED ([CustomerID] ASC)
);

CREATE TABLE [dbo].[CustomerDetails] (
    [CDid]     INT          IDENTITY (1, 1) NOT NULL,
    [Name]     VARCHAR (50) NULL,
    [Age]      INT          NULL,
    [Address]  VARCHAR (50) NULL,
    [MobileNo] VARCHAR (50) NULL,
    [PanNo]    VARCHAR (50) NULL,
    [District] VARCHAR (50) NULL,
    [Pincode]  VARCHAR (50) NULL,
    PRIMARY KEY CLUSTERED ([CDid] ASC)
);

CREATE TABLE [dbo].[EmployeeDB] (
    [EmployeeID] INT           IDENTITY (1, 1) NOT NULL,
    [Username]   VARCHAR (50)  NULL,
    [Password]   VARCHAR (50)  NULL,
    [Name]       VARCHAR (100) NULL,
    [Role]       VARCHAR (50)  NULL,
    [Email]      VARCHAR (100) NULL,
    [Phone]      VARCHAR (20)  NULL,
    PRIMARY KEY CLUSTERED ([EmployeeID] ASC)
);

CREATE TABLE [dbo].[TransactionDB] (
    [TransactionID]   INT             IDENTITY (1, 1) NOT NULL,
    [AccountNumber]   NVARCHAR (50)   NULL,
    [Name]            VARCHAR (50)    NULL,
    [MobileNo]        VARCHAR (50)    NULL,
    [Trans_type]      VARCHAR (50)    NULL,
    [AccountBalance]  DECIMAL (18, 2) NULL,
    [Deposit]         DECIMAL (18, 2) NULL,
    [Withdrawl]       DECIMAL (18, 2) NULL,
    [TransactionDate] DATETIME        NULL,
    PRIMARY KEY CLUSTERED ([TransactionID] ASC)
);

CREATE TABLE [dbo].[UserDB] (
    [UserID]      INT           IDENTITY (1, 1) NOT NULL,
    [Username]    VARCHAR (50)  NOT NULL,
    [Password]    VARCHAR (255) NOT NULL,
    [ConfirmPass] VARCHAR (255) NULL,
    [PhoneNo]     VARCHAR (50)  NOT NULL,
    [Email]       VARCHAR (100) NULL,
    PRIMARY KEY CLUSTERED ([UserID] ASC),
    UNIQUE NONCLUSTERED ([Username] ASC),
    UNIQUE NONCLUSTERED ([Email] ASC)
);


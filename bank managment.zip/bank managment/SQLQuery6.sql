﻿CREATE VIEW banking AS
SELECT *
FROM AccountDB a
INNER JOIN BalanceDB b
ON a.aid = b.accountnumber;


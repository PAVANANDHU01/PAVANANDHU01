﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Web_authentication_project.Models
{
    public class MenuDetailsViewModel
    {
        public int Id { get; set; }
        public string Items { get; set; }
        public Nullable<decimal> Price_per_unit { get; set; }               
       
        public string Fooditems { get; set; }
           
        public string ImageUrl { get; set; }

    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using Web_authentication_project.Models;

namespace Web_authentication_project.Controllers
{
    public class LoginController : Controller
    {
        LoginDBEntities3 d = new LoginDBEntities3();
        // GET: Login
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Index(UserDB user)
        {
            if (ModelState.IsValid)
            {
                bool IsValid = d.UserDBs.Any(u => u.Username == user.Username.ToString() && u.Password == user.Password.ToString());
                if (IsValid)
                {
                    FormsAuthentication.SetAuthCookie(user.Username, false);
                    var use = d.UserDBs.Where(u => u.Username == user.Username).FirstOrDefault();
                    var id = d.UserDBs.Find(use.Id);
                    if (id.Rid == 1)
                    {
                        Session["Role"] = "Admin";
                    }
                    else
                    {
                        Session["Role"] = null;
                    }
                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    ViewBag.Message = "Invalid UserName Or Password ";
                }
            }
            return View();
        }
        public ActionResult Register()
        {
            
            roles();
            return View();
        }

        [HttpPost]
        public ActionResult Register(UserDB user)
        {
            if (ModelState.IsValid)
            {
                var check = d.UserDBs.Where(m => m.Username == user.Username).FirstOrDefault();
                if (check == null)
                {
                    if (user.Password == user.Confirmpassword)
                    {
                        
                        roles();
                        d.UserDBs.Add(user);
                        d.SaveChanges();
                    }
                    else
                    {
                        
                        roles();
                        ModelState.AddModelError("", "Password does not Match");
                        return View();
                    }
                }
                else
                {
                    roles();
                    
                    ModelState.AddModelError("", "UserName Already Registered");
                    return View();
                }
            }
            return View("Index");
        }

        private void roles()
        {
            ViewBag.Rid = new SelectList(d.RoleDBs, "Rid", "Role");
        }
        public ActionResult SignOut()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Index");
        }
        public ActionResult list()
        {
            return View(d.UserDBs.ToList());
        }
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            UserDB br = d.UserDBs.Find(id);
            if (br == null)
            {
                return HttpNotFound();
            }
            return View(br);
        }        
    }
}
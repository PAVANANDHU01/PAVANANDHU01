﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Web_authentication_project.Models;

namespace Web_authentication_project.Controllers
{
    public class HomeController : Controller
    {
        LoginDBEntities3 d = new LoginDBEntities3();
        // GET: Home
        [Authorize]
        public ActionResult Index()
        {
            return View();

        }
        public ActionResult About()
        {
            var result = (from MenuDeatils in d.MenuDBs
                          join FoodcatDB in d.FoodcatDBs on MenuDeatils.Fooditem equals FoodcatDB.Fooditem
                          select new MenuDetailsViewModel
                          {
                              Id = MenuDeatils.Id,
                              Items = MenuDeatils.Items,
                              Price_per_unit = MenuDeatils.Price_per_unit,
                              Fooditems = FoodcatDB.Fooditems,
                              ImageUrl = MenuDeatils.ImageUrl
                          }).ToList();

            return View(result);
        }

        public ActionResult FilterByFoodItem(string foodItem)
        {
            var result = (from MenuDeatils in d.MenuDBs
                          join FoodcatDB in d.FoodcatDBs on MenuDeatils.Fooditem equals FoodcatDB.Fooditem
                          where string.IsNullOrEmpty(foodItem) || FoodcatDB.Fooditems == foodItem
                          select new MenuDetailsViewModel
                          {
                              Id = MenuDeatils.Id,
                              Items = MenuDeatils.Items,
                              Price_per_unit = MenuDeatils.Price_per_unit,
                              Fooditems = FoodcatDB.Fooditems,
                              ImageUrl = MenuDeatils.ImageUrl
                          }).ToList();

            return PartialView("_MenuItemsPartial", result);
        }


    
        public ActionResult Contact()
        {
            return View();
        }
    }
}

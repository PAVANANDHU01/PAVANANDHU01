﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using System.Web.UI.WebControls;
using Web_authentication_project.Models;

namespace Web_authentication_project.Controllers
{
    public class MenuController : Controller
    {
        LoginDBEntities3 d = new LoginDBEntities3();
        // GET: Menu
        public ActionResult Index()
        {
            ViewBag.Fooditem = new SelectList(d.FoodcatDBs, "Fooditem", "Fooditems");
            return View();
        }
        [HttpPost]
        public ActionResult Index(MenuDB user, HttpPostedFileBase file)
        {
            if (ModelState.IsValid && user.Items != null && user.Price_per_unit != null && user.Quantity != null && file != null)
            {
                ViewBag.Fooditem = new SelectList(d.FoodcatDBs, "Fooditem", "Fooditems");
                user.Total_price = user.Price_per_unit * user.Quantity;

                var fileName = Path.GetFileName(file.FileName);
                var directoryToSave = Server.MapPath(Url.Content("~/Content/images"));
                var pathToSave = Path.Combine(directoryToSave, fileName);
                file.SaveAs(pathToSave);
                user.ImageUrl = "~/Content/images/" + fileName;
                d.MenuDBs.Add(user);
                d.SaveChanges();
                return RedirectToAction("menufilter");
            }
            else
            {
                ViewBag.Fooditem = new SelectList(d.FoodcatDBs, "Fooditem", "Fooditems");
                ViewBag.Message = "Please fill all the fields";
                return View(user);
            }
        }
        //public ActionResult foodlist()
        //{
        //    var Fooditem = new SelectList(d.FoodcatDBs, "Fooditem", "Fooditems");
        //    ViewBag.Fooditem = Fooditem;
        //    var g = Fooditem.SelectedValues;
        //    return View(d.MenuDBs.ToList());
        //}
        public ActionResult delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            MenuDB del = d.MenuDBs.Find(id);
            if (del == null)
            {
                return HttpNotFound();
            }
            return View(del);
        }
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult deleteconfirm(int id)
        {
            try
            {
                MenuDB del = d.MenuDBs.Find(id);
                if (del == null)
                {
                    return HttpNotFound();
                }
                d.MenuDBs.Remove(del);
                d.SaveChanges();
                return RedirectToAction("menufilter");
            }
            catch (Exception ex)
            {
                // Log the exception or handle it appropriately
                ModelState.AddModelError("", "This Food Item already ordered the customer so we cannot delete");
                return View();
            }            
        }
        public ActionResult edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            MenuDB user = d.MenuDBs.Find(id);
            if (user == null)
            {
                return HttpNotFound();
            }
            ViewBag.Fooditem = new SelectList(d.FoodcatDBs, "Fooditem", "Fooditems",user.Fooditem);
            return View(user);
        }
        [HttpPost]
        public ActionResult edit(MenuDB user)
        {
            if (ModelState.IsValid)
            {
                ViewBag.Fooditem = new SelectList(d.FoodcatDBs, "Fooditem", "Fooditems");
                user.Total_price = user.Quantity * user.Price_per_unit;
                d.Entry(user).State = EntityState.Modified;
                d.SaveChanges();
                return RedirectToAction("menufilter");
            }
            ViewBag.Fooditem = new SelectList(d.FoodcatDBs, "Fooditem", "Fooditems");
            return View();
        }
       
        public ActionResult menufilter(string Fooditem = null)
        {
            List<MenuDB> filteredOrders;

            if (Fooditem == "VEG")
            {
                filteredOrders = d.MenuDBs.Where(o => o.FoodcatDB != null && o.FoodcatDB.Fooditems == "VEG").ToList();
            }
            else if (Fooditem == "NON-VEG")
            {
                filteredOrders = d.MenuDBs.Where(o => o.FoodcatDB != null && o.FoodcatDB.Fooditems == "NON-VEG").ToList();
            }
            else
            {
                filteredOrders = d.MenuDBs.ToList();
            }
            ViewBag.FoodType = new SelectList(new[] { "All", "VEG", "NON-VEG" }, Fooditem);
            return View(filteredOrders);
        }

        public ActionResult menuindex(string Fooditem = null)
        {
            List<MenuDB> filteredOrders;

            if (Fooditem == "VEG")
            {
                filteredOrders = d.MenuDBs.Where(o => o.FoodcatDB != null && o.FoodcatDB.Fooditems == "VEG").ToList();
            }
            else if (Fooditem == "NON-VEG")
            {
                filteredOrders = d.MenuDBs.Where(o => o.FoodcatDB != null && o.FoodcatDB.Fooditems == "NON-VEG").ToList();
            }
            else
            {
                filteredOrders = d.MenuDBs.ToList();
            }
            ViewBag.FoodType = new SelectList(new[] { "All", "VEG", "NON-VEG" }, Fooditem);
            return View(filteredOrders);
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Web_authentication_project.Models;

namespace Web_authentication_project.Controllers
{
    public class UserController : Controller
    {
        LoginDBEntities3 d = new LoginDBEntities3();
        // GET: User
        public ActionResult Index()
        {
            if (Session["Role"] != null)
            {
                return View(d.UserDBs.ToList());
            }
            else
            {
                return HttpNotFound();
            }
        }
        public ActionResult list()
        {
            return View();
        }
        public ActionResult edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            UserDB user = d.UserDBs.Find(id);
            if (user == null)
            {
                return HttpNotFound();
            }
            ViewBag.Rid = new SelectList(d.RoleDBs, "Rid", "Role");
            return View(user);
        }
        [HttpPost]
        public ActionResult edit(UserDB user)
        {
            if (ModelState.IsValid)
            {
                ViewBag.Rid = new SelectList(d.RoleDBs, "Rid", "Role");
                d.Entry(user).State = EntityState.Modified;
                d.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Rid = new SelectList(d.RoleDBs, "Rid", "Role");
            return View();
        }
        public ActionResult delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            UserDB regis = d.UserDBs.Find(id);
            if (regis == null)
            {
                return HttpNotFound();
            }
            return View(regis);
        }
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult deleteconfirm(int id)
        {
            UserDB regis = d.UserDBs.Find(id);
            d.UserDBs.Remove(regis);
            d.SaveChanges();
            return RedirectToAction("Index");
        }
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            UserDB br = d.UserDBs.Find(id);
            if (br == null)
            {
                return HttpNotFound();
            }
            return View(br);
        }

    }
}
﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Web_authentication_project.Models;

namespace Web_authentication_project.Controllers
{
    public class OrderController : Controller
    {
        LoginDBEntities3 d = new LoginDBEntities3();
        // GET: Order
        public ActionResult Index()
        {
            string loggedInUserEmail =User.Identity.Name;
            var emails = d.OrderDBs.Where(e => e.customer_name == loggedInUserEmail).ToList();
            return View(emails.ToList());            
        }
      
        public ActionResult create(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            MenuDB user = d.MenuDBs.Find(id);
            if (user == null)
            {
                return HttpNotFound();
            }
            var get = d.MenuDBs.Where(x => x.Items == user.Items).FirstOrDefault();
            ViewBag.Fooditem = new SelectList(d.FoodcatDBs, "Fooditem", "Fooditems", user.Fooditem);
            ViewBag.FoodName = new SelectList(d.MenuDBs, "Id", "Items",get.Id);
            return View();
        }
        [HttpPost]       
        public ActionResult Create(OrderDB user)
        {
            if (User.Identity.IsAuthenticated)
            {
                user.customer_name = User.Identity.Name;
                if (ModelState.IsValid)
                {
                    if (user.Quantity != null)
                    {
                        if (!string.IsNullOrEmpty(user.customer_name) && user.Quantity > 0)
                        {
                            user.date_of_order = DateTime.Now.ToString();
                            var selectedItem = d.MenuDBs.Find(user.FoodName);
                            var g = user.FoodName;
                            MenuDB S = d.MenuDBs.Find(g);
                            user.total_price = user.Quantity * S.Price_per_unit;
                            if (selectedItem != null)
                            {
                                if (selectedItem.Quantity <= 0)
                                {
                                    ModelState.AddModelError("", "Stock Not Available");                                   
                                    PopulateDropdowns();
                                    return View(user);
                                }
                                else if (selectedItem.Quantity < user.Quantity)
                                {
                                    ModelState.AddModelError("", "Stock Available only: " + selectedItem.Quantity + " Quantity. Please enter Quantity as per stock available");                                   
                                    PopulateDropdowns();
                                    return View(user);
                                }
                                else
                                {
                                    selectedItem.Quantity -= user.Quantity;
                                    selectedItem.Total_price -= user.total_price;
                                    user.total_price = user.Quantity * selectedItem.Price_per_unit;
                                    user.FoodName = selectedItem.Id;
                                    d.OrderDBs.Add(user);
                                    d.SaveChanges();
                                    return RedirectToAction("Index");
                                }
                            }
                        }
                    }
                    else
                    {                        
                        ModelState.AddModelError("","Enter the Quantity");
                    }
                }                               
                               
            }         
            PopulateDropdowns();
            return View(user);
        }
                              
        private void PopulateDropdowns()
        {
            ViewBag.Fooditem = new SelectList(d.FoodcatDBs, "Fooditem", "Fooditems");
            ViewBag.FoodName = new SelectList(d.MenuDBs, "Id", "Items");            
        }                                                    
                              
        public ActionResult edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            OrderDB user = d.OrderDBs.Find(id);
            if (user == null)
            {
                return HttpNotFound();
            }
            ViewBag.Fooditem = new SelectList(d.FoodcatDBs, "Fooditem", "Fooditems", user.Fooditem);
            ViewBag.FoodName = new SelectList(d.MenuDBs, "Id", "Items", user.FoodName);
            return View(user);
        }
        
        [HttpPost]
        public ActionResult edit(OrderDB user)
        {
            if (ModelState.IsValid)
            {
                ViewBag.Fooditem = new SelectList(d.FoodcatDBs, "Fooditem", "Fooditems");
                ViewBag.FoodName = new SelectList(d.MenuDBs, "Id", "Items");
                var data = d.MenuDBs.Where(x => x.Id == user.FoodName).FirstOrDefault();
                user.total_price = user.Quantity * data.Price_per_unit;
                data.Quantity -= user.Quantity;
                d.Entry(user).State = EntityState.Modified;
                d.SaveChanges();
                return RedirectToAction("Index", "Order");
            }
            ViewBag.Fooditem = new SelectList(d.FoodcatDBs, "Fooditem", "Fooditems");
            ViewBag.FoodName = new SelectList(d.MenuDBs, "Id", "Items");
            return View();
        }       

        public ActionResult delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            OrderDB od = d.OrderDBs.Find(id);      
            if (od == null)
            {
                return HttpNotFound();
            }
            return View(od);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult deleteconfirm(int id)
        {
            OrderDB od = d.OrderDBs.Find(id);
            var F = od.FoodName;
            MenuDB p = d.MenuDBs.Find(F);
            if (d.OrderDBs.Remove(od) != null)
            {
                p.Quantity += od.Quantity;
                p.Total_price = p.Quantity * p.Price_per_unit;
            }
            d.SaveChanges();
            return RedirectToAction("Index");
        }
        
        public JsonResult GetFoodNames(int foodItem)
        {
            var filteredFoodNames = d.MenuDBs.Where(m => m.Fooditem == foodItem)
                                              .Select(m => new { Id = m.Id, Items = m.Items })
                                              .ToList();
            return Json(filteredFoodNames, JsonRequestBehavior.AllowGet);
        }        
    }
}


